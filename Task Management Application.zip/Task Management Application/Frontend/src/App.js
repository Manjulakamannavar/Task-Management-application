import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import TaskList from './components/TaskList';
import TaskDetail from './components/TaskDetail';
import TaskForm from './components/TaskForm';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <Router>
      <div className="container">
        <h1>Task Management Application</h1>
        <Switch>
          <Route path="/" exact component={TaskList} />
          <Route path="/tasks/:id" component={TaskDetail} />
          <Route path="/new" component={TaskForm} />
          <Route path="/edit/:id" component={TaskForm} />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
