import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useHistory, useParams } from 'react-router-dom';

const TaskForm = () => {
  const { id } = useParams();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState('');
  const history = useHistory();

  useEffect(() => {
    if (id) {
      axios.get(`/api/tasks/${id}`)
        .then(response => {
          const { title, description, dueDate } = response.data;
          setTitle(title);
          setDescription(description);
          setDueDate(dueDate);
        });
    }
  }, [id]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const task = { title, description, dueDate };

    if (id) {
      axios.put(`/api/tasks/${id}`, task)
        .then(() => {
          history.push('/');
        });
    } else {
      axios.post('/api/tasks', task)
        .then(() => {
          history.push('/');
        });
    }
  };

  return (
    <div>
      <h2>{id ? 'Edit Task' : 'New Task'}</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Title</label>
          <input type="text" className="form-control" value={title} onChange={(e) => setTitle(e.target.value)} required />
        </div>
        <div className="form-group">
          <label>Description</label>
          <textarea className="form-control" value={description} onChange={(e) => setDescription(e.target.value)} required />
        </div>
        <div className="form-group">
          <label>Due Date</label>
          <input type="date" className="form-control" value={dueDate} onChange={(e) => setDueDate(e.target.value)} required />
        </div>
        <button type="submit" className="btn btn-primary">{id ? 'Update Task' : 'Create Task'}</button>
      </form>
    </div>
  );
};

export default TaskForm;
